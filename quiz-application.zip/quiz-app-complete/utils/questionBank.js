const questions = [
  { question: 'What is 2 + 2?', answer: '4' },
];

const getRandomQuestions = (num) => {
  return questions.sort(() => 0.5 - Math.random()).slice(0, num);
};

module.exports = { getRandomQuestions };
