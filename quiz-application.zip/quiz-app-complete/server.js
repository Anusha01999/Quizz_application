const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const app = express();
const server = http.createServer(app);
const io = socketIo(server);
const { getRandomQuestions } = require('./utils/questionBank');
const rooms = {};

app.use(express.json());
app.use('/api', require('./routes/lobby'));

io.on('connection', (socket) => {
  socket.on('joinRoom', ({ roomId, userId }) => {
    socket.join(roomId);
    rooms[roomId].users.push(userId);

    if (rooms[roomId].users.length === 2) {
      rooms[roomId].questions = getRandomQuestions(5);
      io.to(roomId).emit('startGame', rooms[roomId].questions);
    }
  });

  socket.on('answer', ({ roomId, userId, answer }) => {
    const room = rooms[roomId];
    const currentQuestion = room.questions.shift();

    if (currentQuestion.answer === answer) {
      room.scores[userId] = (room.scores[userId] || 0) + 10;
    }

    if (room.questions.length === 0) {
      io.to(roomId).emit('endGame', room.scores);
      delete rooms[roomId];
    }
  });
});

server.listen(3000, () => console.log('Server running on port 3000'));
