const express = require('express');
const router = express.Router();
const { createRoom, getRooms, joinRoom } = require('../controllers/gameController');

router.get('/rooms', getRooms);
router.post('/rooms', createRoom);
router.post('/join', joinRoom);

module.exports = router;
