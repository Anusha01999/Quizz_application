const Room = require('../models/room');
const rooms = {};

const createRoom = (req, res) => {
  const id = `room-${Object.keys(rooms).length + 1}`;
  rooms[id] = new Room(id);
  res.status(201).send({ roomId: id });
};

const getRooms = (req, res) => {
  const availableRooms = Object.values(rooms).filter(room => room.users.length < 2);
  res.status(200).send(availableRooms);
};

const joinRoom = (req, res) => {
  const { roomId, userId } = req.body;
  if (rooms[roomId] && rooms[roomId].users.length < 2) {
    rooms[roomId].users.push(userId);
    res.status(200).send({ success: true });
  } else {
    res.status(400).send({ success: false, message: 'Room is full or does not exist' });
  }
};

module.exports = { createRoom, getRooms, joinRoom };
