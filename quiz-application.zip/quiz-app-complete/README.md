# Real-Time Quiz Application

## Description
This is a real-time quiz application built using Node.js, Express, Socket.IO, and MongoDB. The application allows users to create or join rooms, answer quiz questions in real-time, and view their scores at the end of the game.

## Features
- Lobby for displaying available rooms
- Matchmaking to join rooms with vacant slots
- Real-time quiz gameplay with questions and answers
- Scoring system to calculate and display user scores
- Room management to create, join, and delete rooms

## Technologies Used
- Node.js
- Express
- Socket.IO
- MongoDB
- HTML, CSS, JavaScript

## Installation

### Prerequisites
- Node.js and npm installed
- MongoDB installed and running locally or use MongoDB Atlas

### Steps

1. **Clone the Repository**
    ```bash
    git clone https://github.com/your-username/quiz-app.git
    cd quiz-app
    ```

2. **Install Dependencies**
    ```bash
    npm install
    ```

3. **Set Up Environment Variables**
    Create a `.env` file in the root directory and add the following environment variables:
    ```plaintext
    MONGO_URI=mongodb://localhost:27017/quiz-app
    ```

4. **Start MongoDB**
    Make sure your MongoDB server is running. If using a local instance, you can start it with:
    ```bash
    mongod
    ```

5. **Run the Application**
    ```bash
    npm start
    ```
    The server will start on `http://localhost:3000`.

## Testing the Application
1. **Access the Lobby**
    Open your browser and navigate to `http://localhost:3000`. You will see the lobby with a list of available rooms.

2. **Create or Join a Room**
    - Click on "Create Room" to create a new room.
    - Click on "Join" next to an available room to join it.

3. **Start the Game**
    Once two users have joined a room, the game will start automatically, and both users will receive questions in real-time.

4. **Answer Questions**
    Type your answer in the input box and click "Submit" within the 10-second window for each question.

5. **View Scores**
    After all questions are answered or 50 seconds have passed, the game will end, and the scores will be displayed.

## Deployment
To deploy the application, you can use platforms like Heroku for the backend and Vercel or Netlify for the frontend.

### Deploy Backend
1. **Create a Heroku Account and Install Heroku CLI**
    Follow the instructions on [Heroku](https://devcenter.heroku.com/articles/heroku-cli) to create an account and install the CLI.

2. **Deploy the Backend**
    ```bash
    heroku create
    git push heroku main
    heroku config:set MONGO_URI=mongodb+srv://your-atlas-uri
    ```

### Deploy Frontend
1. **Create an Account on Vercel or Netlify**
    Follow the instructions on [Vercel](https://vercel.com) or [Netlify](https://www.netlify.com) to create an account.

2. **Deploy the Frontend**
    - Drag and drop the `public` folder in your Vercel or Netlify dashboard for deployment.
    - Ensure that your backend URL is set correctly in your frontend JavaScript file.

## Video Demonstration
Record a video demonstrating the application's functionality, including:
- Creating and joining rooms
- Answering questions
- Displaying the result at the end of the game

## License
This project is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Contributing
If you would like to contribute, please fork the repository and use a feature branch. Pull requests are welcome.

## Contact
For any issues or inquiries, please contact [your-email@example.com].
